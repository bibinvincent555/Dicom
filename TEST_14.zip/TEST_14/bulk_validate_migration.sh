#!/bin/bash

# Usage: ./bulk_validate_migration.sh <basepath> [sample_percentage]
# Example: ./bulk_validate_migration.sh /mnt/disk3 10  # Validates 10% of studies

BASEPATH="$1"
SAMPLE_PERCENTAGE="${2:-100}"  # Default to 100% if not specified

# Configuration (adjust these)
SOURCE_DB_HOST="192.168.180.203"
SOURCE_DB_PORT="3307"
SOURCE_DB_USER="root"
SOURCE_DB_PASS="Bibin"
SOURCE_DB_NAME="pacsdb_m"

# Get all StudyUIDs from source
STUDY_UIDS=$(mysql -u"$SOURCE_DB_USER" -p"$SOURCE_DB_PASS" -h"$SOURCE_DB_HOST" -P"$SOURCE_DB_PORT" -N -e "SELECT study_iuid FROM study;" "$SOURCE_DB_NAME")

# Sample if percentage is less than 100
if [[ "$SAMPLE_PERCENTAGE" -lt 100 ]]; then
  TOTAL_STUDIES=$(echo "$STUDY_UIDS" | wc -l)
  SAMPLE_SIZE=$((TOTAL_STUDIES * SAMPLE_PERCENTAGE / 100))
  STUDY_UIDS=$(echo "$STUDY_UIDS" | shuf -n "$SAMPLE_SIZE")
fi

# Run validation in parallel (adjust -j based on your system)
echo "$STUDY_UIDS" | parallel -j 4 ./validate_migration.sh {} "$BASEPATH"

echo "✅ Validation complete. Check logs for details (validation_<StudyUID>.log)."

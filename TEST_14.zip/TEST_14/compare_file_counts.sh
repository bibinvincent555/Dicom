#!/bin/bash

# Usage: ./compare_file_counts.sh /mnt/disk3

BASEPATH="$1"

if [[ -z "$BASEPATH" || ! -d "$BASEPATH" ]]; then
  echo "❌ Please provide a valid basepath directory."
  echo "👉 Usage: $0 /mnt/disk3"
  exit 1
fi

# Count files in source basepath
SOURCE_FILE_COUNT=$(find "$BASEPATH" -type f | wc -l)

# Count files in target (APACSVNA storage - adjust this path)
TARGET_STORAGE_PATH="/var/lib/dcm4chee-arc/storage"
TARGET_FILE_COUNT=$(find "$TARGET_STORAGE_PATH" -type f | wc -l)

echo "File Count: Source = $SOURCE_FILE_COUNT, Target = $TARGET_FILE_COUNT"

if [[ "$SOURCE_FILE_COUNT" -eq "$TARGET_FILE_COUNT" ]]; then
  echo "✅ File counts match."
else
  echo "❌ File counts do not match. Please investigate."
fi

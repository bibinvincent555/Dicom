#!/bin/bash

# Usage: ./run_one_disk.sh <fsID>
FS_ID=$1

if [[ -z "$FS_ID" ]]; then
  echo "❌ Please provide a filesystem ID (e.g., 1, 2, 3)"
  echo "👉 Usage: ./run_one_disk.sh 1"
  exit 1
fi

# -------------------------------------------
# CONFIGURATION
# -------------------------------------------
API_URL="http://192.168.180.203:8080/dcm4chee-arc"
LOCAL_AET="APACSVNA"
REMOTE_AET="APACS"
DEST_AET="APACSVNA"

DISK_LIST_DIR="./DISK_LIST"
LOG_DIR="./logs"
SUMMARY_FILE="./migration_summary.csv"

DISK_FILE="$DISK_LIST_DIR/fs${FS_ID}.txt"
LOG_FILE="$LOG_DIR/fs${FS_ID}.log"

# -------------------------------------------
# Ensure required folders exist
# -------------------------------------------
mkdir -p "$LOG_DIR"

# -------------------------------------------
# Function to fetch token
# -------------------------------------------
fetch_token() {
  TOKEN=$(./get_token.sh)
  if [[ -z "$TOKEN" || "$TOKEN" == "null" ]]; then
    echo "❌ Failed to fetch token. Exiting."
    exit 1
  fi
}

# -------------------------------------------
# Fetch initial token
# -------------------------------------------
echo "🔑 Fetching Keycloak token..."
fetch_token

# -------------------------------------------
# Initialize log
# -------------------------------------------
echo "📦 Processing Disk: fs${FS_ID}"
echo "-----------------------------" > "$LOG_FILE"
echo "Start time: $(date)" >> "$LOG_FILE"

TOTAL=0
SUCCESS=0
FAILURE=0

# -------------------------------------------
# Ensure disk file exists and is not empty
# -------------------------------------------
if [[ ! -s "$DISK_FILE" ]]; then
  echo "❌ Disk file $DISK_FILE is missing or empty. Exiting."
  exit 1
fi

# -------------------------------------------
# Read and process unique UIDs
# -------------------------------------------
mapfile -t UNIQUE_UIDS < <(sort -u "$DISK_FILE")

for STUDY_UID in "${UNIQUE_UIDS[@]}"; do
    [[ -z "$STUDY_UID" ]] && continue

    TOTAL=$((TOTAL+1))
    echo "➡️  Migrating Study: $STUDY_UID"

    attempt=1
    while [[ $attempt -le 2 ]]; do
        RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
          "$API_URL/aets/$LOCAL_AET/dimse/$REMOTE_AET/studies/export/dicom:$DEST_AET?StudyInstanceUID=$STUDY_UID" \
          -H "Authorization: Bearer $TOKEN" \
          -H "Content-Type: application/json" \
          -d "{}")

        if [[ "$RESPONSE" == "202" ]]; then
            echo "[SUCCESS] $STUDY_UID" >> "$LOG_FILE"
            SUCCESS=$((SUCCESS+1))
            break
        elif [[ "$RESPONSE" == "401" && $attempt -eq 1 ]]; then
            echo "⚠️ Token expired. Refreshing token..."
            fetch_token
            attempt=$((attempt + 1))
            continue
        else
            echo "[FAILURE] $STUDY_UID - HTTP $RESPONSE" >> "$LOG_FILE"
            FAILURE=$((FAILURE+1))
            break
        fi
    done

    #sleep 0.5
done

# -------------------------------------------
# Finalize log
# -------------------------------------------
echo "End time: $(date)" >> "$LOG_FILE"
echo "✅ Success: $SUCCESS" >> "$LOG_FILE"
echo "❌ Failure: $FAILURE" >> "$LOG_FILE"

# -------------------------------------------
# Update summary
# -------------------------------------------
echo "fs${FS_ID},$TOTAL,$SUCCESS,$FAILURE" >> "$SUMMARY_FILE"

echo "✅ Done processing fs${FS_ID}. Log saved to $LOG_FILE"


#!/bin/bash

# Usage: ./retry_failed_for_file.sh failed_uids/<your_failed_file>.txt

UID_FILE="$1"

if [[ -z "$UID_FILE" || ! -f "$UID_FILE" ]]; then
  echo "❌ Please provide a valid file containing StudyInstanceUIDs to retry."
  echo "👉 Usage: $0 failed_uids/<your_failed_file>.txt"
  exit 1
fi

# Configuration
API_URL="http://192.168.180.203:8080/dcm4chee-arc"
LOCAL_AET="APACSVNA"
REMOTE_AET="APACS"
DEST_AET="APACSVNA"

LOG_DIR="./logs"
SUMMARY_FILE="./retry_summary.csv"
BASENAME=$(basename "$UID_FILE" .txt)
LOG_FILE="$LOG_DIR/${BASENAME}_retry.log"
RETRY_FAILED_FILE="./failed_uids/${BASENAME}_retry_failed.txt"

mkdir -p "$LOG_DIR" "./failed_uids"

# Health Check
check_health() {
  HEALTH_RESPONSE=$(curl -s -m 10 -o /dev/null -w "%{http_code}" "$API_URL/health" 2>/dev/null)
  if [[ "$HEALTH_RESPONSE" != "200" ]]; then
    echo "❌ Service is down. Health check failed with status $HEALTH_RESPONSE."
    return 1
  fi
  return 0
}

# Get fresh token
get_token() {
  ./get_token.sh
}

# Start
echo "🔁 Retrying migration for UIDs in: $UID_FILE"
echo "-----------------------------" > "$LOG_FILE"
echo "Start time: $(date)" >> "$LOG_FILE"

TOTAL=0
INITIATED=0
FAILURE=0

mapfile -t UNIQUE_UIDS < <(sort -u "$UID_FILE")

TOKEN=$(get_token)
[[ -z "$TOKEN" ]] && echo "❌ Failed to get token. Exiting." && exit 1

for STUDY_UID in "${UNIQUE_UIDS[@]}"; do
  [[ -z "$STUDY_UID" ]] && continue
  TOTAL=$((TOTAL + 1))
  echo "➡️ Retrying Study: $STUDY_UID"

  attempt=1
  max_attempts=3
  while [[ $attempt -le $max_attempts ]]; do
    if ! check_health; then
      echo "🔁 Service down. Retrying after 10 seconds... (Attempt $attempt)" >> "$LOG_FILE"
      sleep 10
      attempt=$((attempt+1))
      continue
    fi

    RESPONSE=$(curl -s -m 30 -o /dev/null -w "%{http_code}" -X POST \
      "$API_URL/aets/$LOCAL_AET/dimse/$REMOTE_AET/studies/export/dicom:$DEST_AET?StudyInstanceUID=$STUDY_UID" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "{}" 2>/dev/null)

    if [[ $? -ne 0 ]]; then
      echo "🔁 Curl error (e.g., timeout). Retrying after 3 seconds... (Attempt $attempt)" >> "$LOG_FILE"
      sleep 3
      attempt=$((attempt+1))
      continue
    fi

    if [[ "$RESPONSE" == "202" ]]; then
      echo "[INITIATED] $STUDY_UID" >> "$LOG_FILE"
      INITIATED=$((INITIATED + 1))
      break
    elif [[ "$RESPONSE" == "401" || "$RESPONSE" == "000" ]]; then
      echo "⚠️ Token expired or server error. Retrying with fresh token..." >> "$LOG_FILE"
      TOKEN=$(get_token)
      [[ -z "$TOKEN" ]] && echo "❌ Cannot continue without token." && exit 1
    else
      echo "[FAILURE] $STUDY_UID - HTTP $RESPONSE" >> "$LOG_FILE"
      echo "$STUDY_UID" >> "$RETRY_FAILED_FILE"
      FAILURE=$((FAILURE + 1))
      break
    fi
    attempt=$((attempt+1))
  done

  if [[ $attempt -gt $max_attempts ]]; then
    echo "[FAILURE] $STUDY_UID - Failed after $max_attempts attempts" >> "$LOG_FILE"
    echo "$STUDY_UID" >> "$RETRY_FAILED_FILE"
    FAILURE=$((FAILURE + 1))
  fi
done

# Summary
echo "End time: $(date)" >> "$LOG_FILE"
echo "✅ Initiated: $INITIATED" >> "$LOG_FILE"
echo "❌ Failure: $FAILURE" >> "$LOG_FILE"

echo "${BASENAME},$TOTAL,$INITIATED,$FAILURE" >> "$SUMMARY_FILE"
echo "📝 Retry log saved: $LOG_FILE"
[[ "$FAILURE" -gt 0 ]] && echo "⚠️ Failed UIDs saved to: $RETRY_FAILED_FILE"

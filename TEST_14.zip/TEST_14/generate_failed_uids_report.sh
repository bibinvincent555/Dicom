#!/bin/bash
# File: generate_failed_uids_report.sh

set -e

# Database connection config
DB_HOST="192.168.180.203"
DB_PORT="3306"
DB_USER="root"
DB_PASS="Amma@123"
DB_NAME="pacsdbvna_m"

# Output files
FAILED_UIDS_FILE="failed_uids.txt"
FAILED_CSV_FILE="failed_uids_detailed.csv"
TMP_RAW="temp_failed_raw.txt"

# Function to translate status codes
get_status_reason() {
  local code="$1"
  case "$code" in
    0) echo "Success,All instances transferred" ;;
    45056) echo "Warning,Some instances failed to transfer" ;;
    45057) echo "Warning,Unable to calculate number of matches" ;;
    45058) echo "Warning,Unable to perform sub-operations" ;;
    272) echo "Failure,Processing failure" ;;
    273) echo "Failure,Duplicate invocation" ;;
    275) echo "Failure,Unrecognized operation" ;;
    281) echo "Failure,Missing required attribute" ;;
    27264) echo "Failure,Out of resources" ;;
    27265) echo "Failure,SOP Class not supported" ;;
    27266) echo "Failure,Cannot understand request" ;;
    27267) echo "Failure,Move Destination AE unknown" ;;
    27268) echo "Failure,Identifier mismatch with SOP Class" ;;
    65535) echo "Failure,Unknown DIMSE failure" ;;
    *) echo "Unknown,Unknown status code" ;;
  esac
}

# Start report generation
echo "📋 Generating failed StudyUIDs report from dcm4chee.task..."

# Check database connectivity
mysql -u "$DB_USER" -p"$DB_PASS" -h "$DB_HOST" -P "$DB_PORT" -e "SELECT 1" "$DB_NAME" >/dev/null 2>&1
if [[ $? -ne 0 ]]; then
    echo "❌ Database connection failed."
    exit 1
fi

# Initialize output files
echo "# Extracted on $(date)" > "$FAILED_UIDS_FILE"
echo "StudyUID,StatusCode,StatusLabel,Reason,ErrorMessage,ErrorComment,TaskStatus" > "$FAILED_CSV_FILE"

# Extract failed or warning tasks
mysql -u "$DB_USER" -p"$DB_PASS" -h "$DB_HOST" -P "$DB_PORT" -D "$DB_NAME" -N -e \
"SELECT study_iuid, status_code, IFNULL(error_msg,''), IFNULL(error_comment,''), task_status 
 FROM task 
 WHERE task_status != 2 OR status_code != 0;" > "$TMP_RAW" 2>/dev/null

if [[ $? -ne 0 ]]; then
    echo "❌ Database query failed."
    rm -f "$TMP_RAW"
    exit 1
fi

# Process each task row
if [[ -s "$TMP_RAW" ]]; then
    while IFS=$'\t' read -r uid code msg comment status; do
        msg_clean=$(echo "$msg" | tr '\n' ' ' | tr -d '\r' | sed 's/,/;/g')
        comment_clean=$(echo "$comment" | tr '\n' ' ' | tr -d '\r' | sed 's/,/;/g')

        reason_info=$(get_status_reason "$code")
        label=$(echo "$reason_info" | cut -d',' -f1)
        reason=$(echo "$reason_info" | cut -d',' -f2)

        echo "$uid" >> "$FAILED_UIDS_FILE"
        echo "\"$uid\",\"$code\",\"$label\",\"$reason\",\"$msg_clean\",\"$comment_clean\",\"$status\"" >> "$FAILED_CSV_FILE"
    done < "$TMP_RAW"
else
    echo "✅ No failed or warning tasks found."
fi

# Cleanup
rm -f "$TMP_RAW"

echo "✅ Done. Failed UIDs saved to: $FAILED_UIDS_FILE"
echo "📄 Detailed failure info saved to: $FAILED_CSV_FILE"

#!/bin/bash

# Configuration (adjust these to match your setup)
SOURCE_DB_HOST="192.168.180.203"
SOURCE_DB_PORT="3307"
SOURCE_DB_USER="root"
SOURCE_DB_PASS="Bibin"
SOURCE_DB_NAME="pacsdb_m"

TARGET_DB_HOST="192.168.180.203"
TARGET_DB_PORT="3306"
TARGET_DB_USER="root"
TARGET_DB_PASS="Amma@123"
TARGET_DB_NAME="pacsdbvna_m"

# Function to get counts from a database
get_counts() {
  local DB_USER="$1"
  local DB_PASS="$2"
  local DB_HOST="$3"
  local DB_PORT="$4"
  local DB_NAME="$5"
  local TABLE="$6"
  mysql -u"$DB_USER" -p"$DB_PASS" -h"$DB_HOST" -P"$DB_PORT" -N -e "SELECT COUNT(*) FROM $TABLE;" "$DB_NAME"
}

# Get counts from source (APACS)
SOURCE_STUDY_COUNT=$(get_counts "$SOURCE_DB_USER" "$SOURCE_DB_PASS" "$SOURCE_DB_HOST" "$SOURCE_DB_PORT" "$SOURCE_DB_NAME" "study")
SOURCE_SERIES_COUNT=$(get_counts "$SOURCE_DB_USER" "$SOURCE_DB_PASS" "$SOURCE_DB_HOST" "$SOURCE_DB_PORT" "$SOURCE_DB_NAME" "series")
SOURCE_INSTANCE_COUNT=$(get_counts "$SOURCE_DB_USER" "$SOURCE_DB_PASS" "$SOURCE_DB_HOST" "$SOURCE_DB_PORT" "$SOURCE_DB_NAME" "instance")

# Get counts from target (APACSVNA)
TARGET_STUDY_COUNT=$(get_counts "$TARGET_DB_USER" "$TARGET_DB_PASS" "$TARGET_DB_HOST" "$TARGET_DB_PORT" "$TARGET_DB_NAME" "study")
TARGET_SERIES_COUNT=$(get_counts "$TARGET_DB_USER" "$TARGET_DB_PASS" "$TARGET_DB_HOST" "$TARGET_DB_PORT" "$TARGET_DB_NAME" "series")
TARGET_INSTANCE_COUNT=$(get_counts "$TARGET_DB_USER" "$TARGET_DB_PASS" "$TARGET_DB_HOST" "$TARGET_DB_PORT" "$TARGET_DB_NAME" "instance")

# Show results
echo "Study Count: Source = $SOURCE_STUDY_COUNT, Target = $TARGET_STUDY_COUNT"
echo "Series Count: Source = $SOURCE_SERIES_COUNT, Target = $TARGET_SERIES_COUNT"
echo "Instance Count: Source = $SOURCE_INSTANCE_COUNT, Target = $TARGET_INSTANCE_COUNT"

if [[ "$SOURCE_STUDY_COUNT" -eq "$TARGET_STUDY_COUNT" && "$SOURCE_SERIES_COUNT" -eq "$TARGET_SERIES_COUNT" && "$SOURCE_INSTANCE_COUNT" -eq "$TARGET_INSTANCE_COUNT" ]]; then
  echo "✅ Database counts match."
else
  echo "❌ Database counts do not match. Please investigate."
fi
